# jquery-snow
Adds a snow falling effect with jQuery :snowflake:
